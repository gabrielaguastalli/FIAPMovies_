package br.com.fiap.movies;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import br.com.fiap.movies.paineis.PainelCadastro;
import br.com.fiap.movies.paineis.PainelLista;

public class App extends JFrame {
	
	private static final long serialVersionUID = 1L;

	private PainelCadastro abaCadastro = new PainelCadastro();
	private PainelLista abaLista = new PainelLista();
	private JTabbedPane abas = new JTabbedPane();
	
	public static void main(String[] args) {
		new App().init();
		
	}

	private void init() {
		//abaLista.add(new JLabel("Filmes Assistidos"));
		
		//abas.add("Filmes Assistidos", abaLista);
		abas.add("Cadastro de Filmes", abaCadastro);
		abas.add("Filmes Assistidos", abaLista);
		
		
		add(abas);
		
		setVisible(true);
		setSize(600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
}
